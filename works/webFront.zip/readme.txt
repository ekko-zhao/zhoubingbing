﻿
项目 框架 webpack angular2
/*
	开发环境 cmd: npm install
*/

开发环境:
	run: npm run dev

生产环境:
	run: npm run build

	
// 项目样式 ----------------------------------------------------------------------------------------
# bootstrap 样式重置
    /* variables.less */
    @brand-primary:         darken(#428bca, 6.5%); // #337ab7
    @brand-success:         #3fb14e;
    @brand-info:            #2bb1e4;
    @brand-warning:         #f0d03b;
    @brand-danger:          #f05050;
	
	修改 border 颜色
	
	修改table hover 等
	
    . 去除 button 圆角

    /* buttons.less */
    . 去除 点击阴影
	
	
/* mixins/buttons.less */
.更改button hover active样式

#引入
    normalize.css
    animate.css

# 添加项目 样式工具  less 编译方式
src/assets/app.less


















































































import { Component } from '@angular/core';

@Component({
    template: `
        <p>billCustom</p>
    `,
})
export class CustomComponent {

}

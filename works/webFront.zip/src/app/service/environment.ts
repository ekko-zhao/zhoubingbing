export const env = {
    itemsPerPage: 20,
    format: 'yMMdd',
    dateRange: 31
}

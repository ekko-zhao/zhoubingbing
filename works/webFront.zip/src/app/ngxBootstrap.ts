
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';

export const ngxBootstrap = [
    BsDropdownModule.forRoot(),
    ModalModule.forRoot()
]

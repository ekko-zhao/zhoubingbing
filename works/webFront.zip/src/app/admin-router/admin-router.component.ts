import { Component } from '@angular/core';

// 当前页面
@Component({
    selector: 'admin-router',
    templateUrl: `./admin-router.html`,
    styleUrls: ['./admin-router.css.less']
})
export class AdminRouterComponent{

}


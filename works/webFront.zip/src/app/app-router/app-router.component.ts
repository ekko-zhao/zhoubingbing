import { Component } from '@angular/core';

// 当前页面
@Component({
    selector: 'app-router',
    templateUrl: `./app-router.html`,
    styleUrls: ['./app-router.css.less']
})
export class AppRouterComponent{

}


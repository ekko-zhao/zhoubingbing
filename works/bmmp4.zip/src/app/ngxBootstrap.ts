
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PaginationModule } from 'ngx-bootstrap/pagination';

export const ngxBootstrap = [
    BsDropdownModule.forRoot(),
    ModalModule.forRoot()
]

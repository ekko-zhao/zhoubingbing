import { Injectable } from "@angular/core";
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { HttpService } from '@service/http-service';

@Injectable()
export class MyService {
    public userData: any;

    // 设置用户名 key:username  用于依据不同的用户记录cookie， 操作可删除的对象 和 需要保留的对象
    private username: string;
    public getUsername() {
        return this.username;
    };

    constructor(
        private cookie: CookieService,
        private http: HttpService,
    ) {
        this.userData = cookie.getObject('userData');
        if (!this.userData) return;

        this.username = cookie.getObject('userData')['name'];
        this.storageInit();

        /* console.log('用户信息');
        console.log(this.userData); */
    }

    // 初始化用户缓存
    /*
        local 用于 储存用户个性化配置
        session 用于 储存用户临时信息
    */
    public storageInit() {
        if (!this.cookie.getObject(this.username)) {
            let data = {
                local: {},
                session: {}
            }
            this.cookie.putObject(this.username, data);
        }
    }

    // 用于设置用户表单缓存 重新登陆时需要清空 username{ session }
    public setStorage(type: string, key: string, obj: Object) {
        let data = this.cookie.getObject(this.username);
        data[type][key] = obj;
        this.cookie.putObject(this.username, data);
    }

    public getStorage(type: string, key?: string) {
        return key ? this.cookie.getObject(this.username)[type][key]
            : this.cookie.getObject(this.username)[type];
    }

    public removeStorage(type: string, key?: string) {
        let data = this.cookie.getObject(this.username);
        if (key) {
            delete data[type][key];
        } else {
            data[type] = {};
        }
        this.cookie.putObject(this.username, data);
    }

    // 导航标题
    public title: string;

    // 当前路由
    public path: string;

    //菜单折叠
    public folded: boolean = false;
    public setFolded() {
        this.folded = !this.folded;
    }


    // 获取下拉列表-----------------------------------------------------------------
    private selectList = {};
    public getSelectList(context, property, type) {
        let selectList = sessionStorage.getItem('selectList');
        if (selectList) {
            this.selectList = JSON.parse(selectList);
            Object.assign(context[property], this.selectList);
        }
        if (!this.selectList[type]) {
            // 异步请求
            this.http.post('api/v1/parameter/queryParam', { "paramKind": type }).subscribe(
                response => {
                    this.selectList[type] = response['data'];
                    Object.assign(context[property], this.selectList);
                    sessionStorage.setItem('selectList', JSON.stringify(this.selectList));
                    console.log(response)
                },
                error => {
                    alert("网络错误，请求下拉列表数据失败");
                }
            )
        }

    }

}

import { Component, Optional } from '@angular/core';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { HttpService } from '@service/http-service';
import { MyService } from '@service/my-service'


@Component({
    selector: 'top-bar',
    templateUrl: 'top-bar.html',
    styleUrls: ['top-bar.css.less'],
    providers: [
        HttpService,
        CookieService
    ]
})

export class TopBarComponent {
    public userData: any;

    constructor(
        @Optional() private myService: MyService,
        private http: HttpService,
        private cookie: CookieService
    ) {
        this.userData = cookie.getObject('userData');
    }

    public quit() {
        sessionStorage.clear();
        this.cookie.remove('userData');
        this.http.get('api/v1/logout').subscribe(
            response => {
                window.location.href = this.userData['type'] !== '100' ? './index.html' : './adminLogin.html';
            },
            error => {
                window.location.href = this.userData['type'] !== '100' ? './index.html' : './adminLogin.html';
            }
        )
    }
}

import { Component, Optional } from '@angular/core';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { HttpService } from '@service/http-service';
import { regex } from '@service/regex';

@Component({
    selector: 'forget-root',
    templateUrl: 'forget.html',
    styleUrls: ['forget.css.less'],
    providers: [
        CookieService,
        HttpService
    ]
})

export class ForgetComponent {
    constructor(
        private http: HttpService,
        private cookie: CookieService
    ) {

    }
    public regex = regex;
    public form = {};
    public codeSrc: string;

    public getVCode() {
        this.codeSrc = "api/v1/captcha.jpg?" + Math.random();
    }

    // 提交
    public submitflag = true;
    public submit() {
        // 阻止二次点击
        if (!this.submitflag) return;
        this.submitflag = !this.submitflag;

        this.http.post('api/v1/user/resetUserPwd', this.form).subscribe(
            response => {
                this.submitflag = !this.submitflag;
                if (response['retCode'] === '000000') {
                    // 跳转页面
                    window.location.href = './login.html';
                } else {
                    alert(response['retMsg']);
                }
            },
            error => {
                this.submitflag = !this.submitflag;
                alert("网络错误，请求数据失败");
            }
        )
    }

    ngOnInit() {
        this.getVCode();
    }

}

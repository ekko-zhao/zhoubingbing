import { Component, Optional } from '@angular/core';
import { MyService } from '@service/my-service';

@Component({
    selector: 'today-general',
    templateUrl: './today-general.html',
    styleUrls: ['./today-general.css.less']
})

export class TodayGeneralComponent {
    constructor(
        @Optional() private myService: MyService
    ){}

}

import { Component, ViewChild } from '@angular/core';
import { CookieService } from 'angular2-cookie/services/cookies.service';
import { HttpService } from '@service/http-service';
import { regex } from '@service/regex';

@Component({
    selector: 'login-root',
    templateUrl: 'login.html',
    styleUrls: ['login.css.less'],
    providers: [
        CookieService,
        HttpService
    ]
})

export class LoginComponent {
    constructor(
        private http: HttpService,
        private cookie: CookieService
    ) { }

    public form = {};
    public regex = regex;
    public loginCache: boolean;
    public codeSrc: string;
    public ipchange: boolean;

    public user: {};
    public transmit = {
        text: '获取短信'
    }
    public getVCode() {
        this.codeSrc = "api/v1/captcha.jpg?" + Math.random();
    }

    // 发送验证码
    public setCode(flag: boolean) {
        if (!flag) return;
        this.http.get('api/v1/user/signCode/' + this.user['data']).subscribe(
            response => {
                if (response['retCode'] === '000000') {
                    console.log('手机验证码发送成功');
                } else {
                    alert(response['retMsg']);
                }
            },
            error => {
                alert("网络错误，请求数据失败");
            }
        )
    }

    // 登陆
    public submitflag = true;
    public submit() {
        // 阻止二次点击
        if (!this.submitflag) return;
        this.submitflag = !this.submitflag;

        if (this.form['proxyMerchant']) {
            this.form['proxyMerchant'] = 1;
        } else {
            this.form['proxyMerchant'] = 0;
        }
        this.http.post('api/v1/login', this.form).subscribe(
            response => {
                this.submitflag = !this.submitflag;

                // 用户超过90天未登录或者IP改变，请输入手机验证码
                if (response['retCode'] === '100016') {
                    this.user = response;
                    this.ipchange = true;
                    return;
                }

                if (response['retCode'] === '000000') {
                    // 清除 用户session
                    let name = response['data']['name'];
                    let cookie = this.cookie.getObject(name);
                    if (cookie) {
                        cookie['session'] = {};
                        this.cookie.putObject(name, cookie);
                    }

                    // 记录用户名
                    if (this.loginCache) {
                        this.cookie.put('loginCache', this.form['name']);
                    } else {
                        this.cookie.remove('loginCache');
                    }

                    // 传递参数
                    response.data['token'] = response['token'];
                    let userData = response.data;
                    this.cookie.putObject('userData', userData);

                    /* 跳转页面 */
                    let url = sessionStorage.getItem('url');

                    // 清除 sessionStorage
                    sessionStorage.clear();
                    if (url) {
                        window.location.href = url;
                    } else {
                        window.location.href = './app.html';
                    }
                } else if (response['retCode'] === '100027') {
                    window.location.href = response['data'];
                } else {
                    alert(response['retMsg']);
                }
            },
            error => {
                this.submitflag = !this.submitflag;
                alert("网络错误，请求数据失败");
            }
        )
    }

    @ViewChild('editForm') public editForm;

    ngOnInit() {
        this.getVCode();
        // 兼容 ie9 placeholder
        setTimeout(() => {
            this.editForm.resetForm();
            setTimeout(() => {
                let cache = this.cookie.get('loginCache');
                if (cache) {
                    this.form['name'] = cache;
                    this.loginCache = true;
                }
            }, 50);
        }, 50);
    }
}

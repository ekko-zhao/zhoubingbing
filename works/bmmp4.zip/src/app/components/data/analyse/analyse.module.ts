import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnalyseComponent } from './analyse.component';
import {CommonModule} from "@angular/common";

const delayingRortes: Routes =[
    {path:'', component: AnalyseComponent}
]

@NgModule({
	imports: [ RouterModule.forChild(delayingRortes), CommonModule ],
	declarations: [
        AnalyseComponent
    ]
})
export class AnalyseModule{}

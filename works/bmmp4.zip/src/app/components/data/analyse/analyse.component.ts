import { Component } from '@angular/core';

@Component({
    template: `
        <p>dataAnalyse</p>
    `,
})
export class AnalyseComponent {

}

import { Component } from '@angular/core';

@Component({
    template: `
        <p>ManageComponent</p>
    `,
})
export class ManageComponent {

}

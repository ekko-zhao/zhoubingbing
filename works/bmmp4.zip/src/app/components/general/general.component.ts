import { Component } from '@angular/core';

@Component({
    template: `
        <p></p>
    `,
})
export class GeneralComponent {

}

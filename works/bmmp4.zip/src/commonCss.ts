import "normalize.css";
import "./assets/bootstrap-3.3.7/dist/css/bootstrap.css";
// import "animate.css";
import "./assets/less/app.less";
import "../node_modules/ngx-bootstrap/datepicker/bs-datepicker.css";


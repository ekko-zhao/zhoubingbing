
!function (e, t) {
    alert(2)

}(this);


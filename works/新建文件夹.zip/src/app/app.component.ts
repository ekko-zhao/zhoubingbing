import { Component, ViewChild } from '@angular/core';
@Component({
    selector: 'app-root',
    template: '<p>app-root</p>'
})

export class AppComponent {
    constructor() {
        const zhoubingbing = 'zhoubingbing23'
        let [a, b] = ['30', '50'];
    }
}

